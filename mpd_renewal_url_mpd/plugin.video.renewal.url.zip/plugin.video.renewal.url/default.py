import sys

import xbmcplugin, xbmcgui

handle = int(sys.argv[1])
path = sys.argv[2]

if 'renew' in sys.argv[2]:
    xbmcplugin.addDirectoryItem(handle, 'https://raw.githubusercontent.com/matthuisman/ia_tests/master/mpd_renewal_url_mpd/token2/token2.mpd', xbmcgui.ListItem(), False)
    xbmcplugin.endOfDirectory(handle, succeeded=True)
elif 'play' in sys.argv[2]:
    li = xbmcgui.ListItem()
    li.setPath('https://raw.githubusercontent.com/matthuisman/ia_tests/master/mpd_renewal_url_mpd/token1/token1.mpd')
    li.setProperty('inputstream', 'inputstream.adaptive')
    li.setProperty('inputstreamaddon', 'inputstream.adaptive')
    li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
    li.setProperty('inputstream.adaptive.media_renewal_url', 'plugin://plugin.video.renewal.url/?renew')
    li.setProperty('inputstream.adaptive.media_renewal_time', '1')
    xbmcplugin.setResolvedUrl(handle, True, li)
else:
    play_path = 'plugin://plugin.video.renewal.url/?play'
    li = xbmcgui.ListItem('Test (success = making it pass 8 seconds)')
    li.setPath(play_path)
    li.setProperty('IsPlayable', 'true')
    li.setInfo('video', {})
    xbmcplugin.addDirectoryItem(handle, play_path, li, False)
    xbmcplugin.endOfDirectory(handle, succeeded=True)